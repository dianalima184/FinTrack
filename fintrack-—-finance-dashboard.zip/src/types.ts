export interface Transaction {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
}

export type Category = 'Food' | 'Income' | 'Housing' | 'Utilities' | 'Entertainment' | 'Other';

export const CATEGORIES: Category[] = ['Food', 'Income', 'Housing', 'Utilities', 'Entertainment', 'Other'];
