import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, 
  Trash2, 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  PieChart as PieChartIcon, 
  ArrowUpRight, 
  ArrowDownRight,
  CircleDollarSign,
  Calendar,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { Transaction, CATEGORIES, Category } from './types.ts';

const CURRENCY_FORMATTER = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

const COLORS = ['#0f172a', '#334155', '#64748b', '#94a3b8', '#cbd5e1', '#e2e8f0'];

export default function App() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);

  // Form State
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<Category>('Other');

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    try {
      const res = await fetch('/api/transactions');
      const data = await res.json();
      setTransactions(data);
    } catch (err) {
      console.error('Failed to fetch transactions', err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description || !amount) return;

    try {
      const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description,
          amount: parseFloat(amount),
          category
        })
      });
      if (res.ok) {
        await fetchTransactions();
        setShowAddModal(false);
        setDescription('');
        setAmount('');
        setCategory('Other');
      }
    } catch (err) {
      console.error('Failed to add transaction', err);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch('/api/transactions/' + id, { method: 'DELETE' });
      setTransactions(prev => prev.filter(t => t.id !== id));
    } catch (err) {
      console.error('Failed to delete transaction', err);
    }
  };

  const stats = useMemo(() => {
    const totalIncome = transactions
      .filter(t => t.amount > 0)
      .reduce((acc, t) => acc + t.amount, 0);
    const totalExpenses = transactions
      .filter(t => t.amount < 0)
      .reduce((acc, t) => acc + Math.abs(t.amount), 0);
    const balance = totalIncome - totalExpenses;

    const categoryData = CATEGORIES.map(cat => {
      const catTotal = transactions
        .filter(t => t.category === cat)
        .reduce((acc, t) => acc + Math.abs(t.amount), 0);
      return { name: cat, value: catTotal };
    }).filter(d => d.value > 0);

    return { totalIncome, totalExpenses, balance, categoryData };
  }, [transactions]);

  return (
    <div className="min-h-screen pb-20">
      {/* Navbar */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-md border-b border-slate-200 z-40 flex items-center px-6">
        <div className="max-w-7xl mx-auto w-full flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center">
              <CircleDollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="font-semibold text-xl tracking-tight">FinTrack</span>
          </div>
          <button 
            onClick={() => setShowAddModal(true)}
            className="bg-slate-900 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-slate-800 transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Transaction
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 pt-24 space-y-8">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="card"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-slate-100 rounded-xl text-slate-600">
                <Wallet className="w-5 h-5" />
              </div>
            </div>
            <p className="text-slate-500 text-sm font-medium">Total Balance</p>
            <h2 className="text-3xl font-semibold tracking-tight mt-1">
              {CURRENCY_FORMATTER.format(stats.balance)}
            </h2>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="card"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-emerald-50 rounded-xl text-emerald-600">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div className="flex items-center text-emerald-600 text-xs font-medium">
                <ArrowUpRight className="w-3 h-3 mr-1" />
                Updated
              </div>
            </div>
            <p className="text-slate-500 text-sm font-medium">Monthly Income</p>
            <h2 className="text-3xl font-semibold tracking-tight mt-1 text-emerald-600">
              {CURRENCY_FORMATTER.format(stats.totalIncome)}
            </h2>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="card"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="p-2 bg-rose-50 rounded-xl text-rose-600">
                <TrendingDown className="w-5 h-5" />
              </div>
              <div className="flex items-center text-rose-600 text-xs font-medium">
                <ArrowDownRight className="w-3 h-3 mr-1" />
                Updated
              </div>
            </div>
            <p className="text-slate-500 text-sm font-medium">Monthly Expenses</p>
            <h2 className="text-3xl font-semibold tracking-tight mt-1 text-rose-600">
              {CURRENCY_FORMATTER.format(stats.totalExpenses)}
            </h2>
          </motion.div>
        </div>

        {/* Charts & Table Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Transactions */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex justify-between items-end">
              <div>
                <h3 className="text-xl font-semibold tracking-tight">Recent Transactions</h3>
                <p className="text-slate-500 text-sm">A list of your latest financial activity.</p>
              </div>
            </div>

            <div className="card !p-0 overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Description</th>
                    <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Category</th>
                    <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Amount</th>
                    <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {loading ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-slate-500">Loading your data...</td>
                    </tr>
                  ) : transactions.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-slate-500">No transactions found. Add one to get started!</td>
                    </tr>
                  ) : (
                    transactions.map((t) => (
                      <motion.tr 
                        layout
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        key={t.id} 
                        className="hover:bg-slate-50 transition-colors group"
                      >
                        <td className="px-6 py-4">
                          <div className="font-medium text-sm">{t.description}</div>
                          <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {new Date(t.date).toLocaleDateString()}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-600">
                            {t.category}
                          </span>
                        </td>
                        <td className={`px-6 py-4 text-right font-semibold text-sm ${t.amount < 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                          {t.amount < 0 ? '-' : '+'}{CURRENCY_FORMATTER.format(Math.abs(t.amount))}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button 
                            onClick={() => handleDelete(t.id)}
                            className="p-2 text-slate-300 hover:text-rose-600 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </motion.tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Side Panels */}
          <div className="space-y-8">
            {/* Category Breakdown */}
            <div className="card">
              <div className="flex items-center gap-2 mb-6">
                <PieChartIcon className="w-5 h-5 text-slate-500" />
                <h3 className="font-semibold tracking-tight">Spending Breakdown</h3>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={stats.categoryData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {stats.categoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip cursor={{ fill: 'transparent' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-2 mt-4">
                {stats.categoryData.map((item, index) => (
                  <div key={item.name} className="flex justify-between items-center text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                      <span className="text-slate-500">{item.name}</span>
                    </div>
                    <span className="font-medium text-slate-900">{CURRENCY_FORMATTER.format(item.value)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Income vs Expenses Progress */}
            <div className="card">
              <h3 className="font-semibold mb-6 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-slate-500" />
                Budget Health
              </h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs mb-2">
                    <span className="text-slate-500 uppercase">Expense Utilization</span>
                    <span className="font-medium">{Math.min(100, Math.round((stats.totalExpenses / (stats.totalIncome || 1)) * 100))}%</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(100, (stats.totalExpenses / (stats.totalIncome || 1)) * 100)}%` }}
                      className={`h-full ${stats.totalExpenses > stats.totalIncome ? 'bg-rose-500' : 'bg-slate-900'}`}
                    />
                  </div>
                </div>
                <p className="text-[11px] text-slate-400 italic">
                  {stats.totalExpenses > stats.totalIncome 
                    ? "Warning: Your expenses exceed your income this period."
                    : "Great! You are spending less than you earn."}
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Add Transaction Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl p-8"
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold tracking-tight">New Transaction</h2>
                <button onClick={() => setShowAddModal(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddTransaction} className="space-y-6">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase mb-2 tracking-wider">Description</label>
                  <input 
                    type="text" 
                    placeholder="Rent, Groceries, Salary..."
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    className="input-field" 
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase mb-2 tracking-wider">Amount</label>
                    <input 
                      type="number" 
                      step="0.01"
                      placeholder="0.00"
                      value={amount}
                      onChange={e => setAmount(e.target.value)}
                      className="input-field" 
                      required
                    />
                    <p className="text-[10px] text-slate-400 mt-1 italic">Use negative for expenses</p>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 uppercase mb-2 tracking-wider">Category</label>
                    <select 
                      className="input-field appearance-none bg-slate-50"
                      value={category}
                      onChange={e => setCategory(e.target.value as Category)}
                    >
                      {CATEGORIES.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <button 
                  type="submit"
                  className="w-full bg-slate-900 text-white py-3 rounded-xl font-semibold hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
                >
                  Confirm Transaction
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
