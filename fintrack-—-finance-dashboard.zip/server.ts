import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory data store for the demo
  let transactions = [
    { id: "1", description: "Grocery Store", amount: -45.50, category: "Food", date: new Date().toISOString() },
    { id: "2", description: "Monthly Salary", amount: 3500.00, category: "Income", date: new Date().toISOString() },
    { id: "3", description: "Coffee Shop", amount: -5.20, category: "Food", date: new Date().toISOString() },
    { id: "4", description: "Rent", amount: -1200.00, category: "Housing", date: new Date().toISOString() },
    { id: "5", description: "Electricity Bill", amount: -85.00, category: "Utilities", date: new Date().toISOString() },
  ];

  // API Routes
  app.get("/api/transactions", (req, res) => {
    res.json(transactions);
  });

  app.post("/api/transactions", (req, res) => {
    const { description, amount, category } = req.body;
    if (!description || typeof amount !== 'number' || !category) {
      return res.status(400).json({ error: "Missing required fields" });
    }
    const newTransaction = {
      id: Math.random().toString(36).substr(2, 9),
      description,
      amount,
      category,
      date: new Date().toISOString(),
    };
    transactions.unshift(newTransaction);
    res.status(201).json(newTransaction);
  });

  app.delete("/api/transactions/:id", (req, res) => {
    const { id } = req.params;
    transactions = transactions.filter((t) => t.id !== id);
    res.status(204).send();
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
